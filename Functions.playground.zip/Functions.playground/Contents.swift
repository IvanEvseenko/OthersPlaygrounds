

let myWallet = [1, 2, 5, 1, 2, 10, 20, 20, 50, 100, 100]

func calculateMoney(_ wallet: [Int]) {
    var sum = 0
    for banknot in wallet {
        sum += banknot
    }
    print("In wallet $\(sum)")
}

calculateMoney(myWallet)
 

//// function with return
func calculateMoneyWithReturn(_ wallet: [Int]) -> Int {
    var sum = 0
    for banknot in wallet {
        sum += banknot
    }
    return sum
}
let walletHas = calculateMoneyWithReturn(myWallet)

////////////
func calculateBanknot(_ wallet: [Int], _ interstedBanknot: Int) -> (Int, Int) {
    
   var sumOfBanknot = 0
   var numbersOfBanknot = 0
    
    for banknot in wallet {
        if banknot == interstedBanknot {
            sumOfBanknot += banknot
           numbersOfBanknot += 1
        }
    }
    return (sumOfBanknot, numbersOfBanknot)
}
let (sumAndNumbersOfInterestBanknot) = calculateBanknot(myWallet, 20)

let (sumOfInterestedBanknot, numberOfInterestedBanknot) = calculateBanknot(myWallet, 100)
sumOfInterestedBanknot
numberOfInterestedBanknot

